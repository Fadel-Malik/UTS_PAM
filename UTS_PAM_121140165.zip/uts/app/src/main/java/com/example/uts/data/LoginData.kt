package com.example.uts.data

import android.content.Context
import androidx.datastore.preferences.createDataStore
import androidx.datastore.preferences.edit
import androidx.datastore.preferences.preferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LoginData (context: Context){
    private val dataStore = context.createDataStore(name = "user_prefs")

    companion object{
        val USER_NAME_KEY = preferencesKey<String>("USER_NAME")
        val USER_PASS_KEY = preferencesKey<String>("USER_PASS")
        val USER_GITHUB_KEY = preferencesKey<String>("USER_GIT")
        val USER_NIK_KEY = preferencesKey<String>("USER_NIK")
        val USER_EMAIL_KEY = preferencesKey<String>("USER_EMAIL")
        val USER_LOGIN_KEY = preferencesKey<Boolean>("USER_LOGIN")
    }

    suspend fun storeUser(Nama:String, Pass:String, Github:String, NIK:String, Email:String){
        dataStore.edit {
            it[USER_NAME_KEY] = Nama
            it[USER_PASS_KEY] = Pass
            it[USER_GITHUB_KEY] = Github
            it[USER_NIK_KEY]= NIK
            it[USER_EMAIL_KEY] = Email
        }
    }

    suspend fun storeLogin(login:Boolean){
        dataStore.edit {
            it[USER_LOGIN_KEY] = login
        }
    }

    fun getUsername():Flow<String>{
        return userNameFlow
    }

    fun getUserGithub():Flow<String>{
        return userGithubFlow
    }

    fun getUserNIK():Flow<String>{
        return userNIKFlow
    }

    fun getUserEmail():Flow<String>{
        return userEmailFlow
    }

    fun getUserPass():Flow<String>{
        return userPassFlow
    }

    private val userNameFlow : Flow<String> = dataStore.data.map {
        it[USER_NAME_KEY] ?: ""
    }

    private val userPassFlow : Flow<String> = dataStore.data.map {
        it[USER_PASS_KEY] ?: ""
    }

    private val userGithubFlow : Flow<String> = dataStore.data.map {
        it[USER_GITHUB_KEY] ?: ""
    }

    private val userNIKFlow : Flow<String> = dataStore.data.map {
        it[USER_NIK_KEY] ?: ""
    }

    private val userEmailFlow : Flow<String> = dataStore.data.map {
        it[USER_EMAIL_KEY] ?: ""
    }

    val userLoginFlow : Flow<Boolean> = dataStore.data.map {
        it[USER_LOGIN_KEY] ?: false
    }
}